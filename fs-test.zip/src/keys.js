module.exports = {

    database: {
        host: 'localhost',
        user: 'Administrador',
        password: 'Admin_01_pwd',
        database: 'db_usuarios'
    }
}